﻿namespace Ax2_BIT502_CassandraSampson
{
    partial class GymMembership
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddButton = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Button();
            this.DataSuccess = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.NetMembershipCost = new System.Windows.Forms.Label();
            this.ExtraCharges = new System.Windows.Forms.Label();
            this.RegPayAmount = new System.Windows.Forms.Label();
            this.TotalDiscount = new System.Windows.Forms.Label();
            this.MembershipCost = new System.Windows.Forms.Label();
            this.RegPayBox = new System.Windows.Forms.TextBox();
            this.NetCostBox = new System.Windows.Forms.TextBox();
            this.ExtraBox = new System.Windows.Forms.TextBox();
            this.MemCostBox = new System.Windows.Forms.TextBox();
            this.TextDiscBox = new System.Windows.Forms.TextBox();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.Extras = new System.Windows.Forms.GroupBox();
            this.fitnessVidCheck = new System.Windows.Forms.CheckBox();
            this.dietConsultCheck = new System.Windows.Forms.CheckBox();
            this.personalTrainerCheck = new System.Windows.Forms.CheckBox();
            this.accessCheck = new System.Windows.Forms.CheckBox();
            this.PaymentDetails = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.creditRadio = new System.Windows.Forms.RadioButton();
            this.bankRadio = new System.Windows.Forms.RadioButton();
            this.frequencylabel = new System.Windows.Forms.Label();
            this.BankAccBox = new System.Windows.Forms.TextBox();
            this.BankNumber = new System.Windows.Forms.Label();
            this.Method = new System.Windows.Forms.Label();
            this.FrequencyCheck = new System.Windows.Forms.Panel();
            this.monthlyRadio = new System.Windows.Forms.RadioButton();
            this.weeklyRadio = new System.Windows.Forms.RadioButton();
            this.MembershipDetails = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.premiumRadio = new System.Windows.Forms.RadioButton();
            this.regularRadio = new System.Windows.Forms.RadioButton();
            this.basicRadio = new System.Windows.Forms.RadioButton();
            this.MembershipDuration = new System.Windows.Forms.Label();
            this.MembershipType = new System.Windows.Forms.Label();
            this.DurationDetails = new System.Windows.Forms.Panel();
            this.months24 = new System.Windows.Forms.RadioButton();
            this.months12 = new System.Windows.Forms.RadioButton();
            this.months3 = new System.Windows.Forms.RadioButton();
            this.CustomerDetails = new System.Windows.Forms.GroupBox();
            this.MobileBox = new System.Windows.Forms.TextBox();
            this.AddressBox = new System.Windows.Forms.TextBox();
            this.LastnameBox = new System.Windows.Forms.TextBox();
            this.FirstnameBox = new System.Windows.Forms.TextBox();
            this.MobileNumber = new System.Windows.Forms.Label();
            this.Firstname = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.Lastname = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.Extras.SuspendLayout();
            this.PaymentDetails.SuspendLayout();
            this.panel2.SuspendLayout();
            this.FrequencyCheck.SuspendLayout();
            this.MembershipDetails.SuspendLayout();
            this.panel3.SuspendLayout();
            this.DurationDetails.SuspendLayout();
            this.CustomerDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddButton
            // 
            this.AddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddButton.Location = new System.Drawing.Point(1139, 1466);
            this.AddButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(200, 63);
            this.AddButton.TabIndex = 42;
            this.AddButton.Text = "Add";
            this.AddButton.UseCompatibleTextRendering = true;
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CloseButton.Location = new System.Drawing.Point(923, 1466);
            this.CloseButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(200, 62);
            this.CloseButton.TabIndex = 41;
            this.CloseButton.Text = "Close";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // DataSuccess
            // 
            this.DataSuccess.Cursor = System.Windows.Forms.Cursors.No;
            this.DataSuccess.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DataSuccess.Location = new System.Drawing.Point(86, 1472);
            this.DataSuccess.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.DataSuccess.Name = "DataSuccess";
            this.DataSuccess.ReadOnly = true;
            this.DataSuccess.Size = new System.Drawing.Size(799, 45);
            this.DataSuccess.TabIndex = 35;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.NetMembershipCost);
            this.panel1.Controls.Add(this.ExtraCharges);
            this.panel1.Controls.Add(this.RegPayAmount);
            this.panel1.Controls.Add(this.TotalDiscount);
            this.panel1.Controls.Add(this.MembershipCost);
            this.panel1.Controls.Add(this.RegPayBox);
            this.panel1.Controls.Add(this.NetCostBox);
            this.panel1.Controls.Add(this.ExtraBox);
            this.panel1.Controls.Add(this.MemCostBox);
            this.panel1.Controls.Add(this.TextDiscBox);
            this.panel1.Location = new System.Drawing.Point(86, 1197);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1253, 248);
            this.panel1.TabIndex = 40;
            // 
            // NetMembershipCost
            // 
            this.NetMembershipCost.AutoSize = true;
            this.NetMembershipCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetMembershipCost.Location = new System.Drawing.Point(613, 108);
            this.NetMembershipCost.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.NetMembershipCost.Name = "NetMembershipCost";
            this.NetMembershipCost.Size = new System.Drawing.Size(309, 36);
            this.NetMembershipCost.TabIndex = 10;
            this.NetMembershipCost.Text = "Net Membership Cost:";
            // 
            // ExtraCharges
            // 
            this.ExtraCharges.AutoSize = true;
            this.ExtraCharges.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraCharges.Location = new System.Drawing.Point(613, 46);
            this.ExtraCharges.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.ExtraCharges.Name = "ExtraCharges";
            this.ExtraCharges.Size = new System.Drawing.Size(212, 36);
            this.ExtraCharges.TabIndex = 9;
            this.ExtraCharges.Text = "Extra Charges:";
            // 
            // RegPayAmount
            // 
            this.RegPayAmount.AutoSize = true;
            this.RegPayAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegPayAmount.Location = new System.Drawing.Point(45, 184);
            this.RegPayAmount.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.RegPayAmount.Name = "RegPayAmount";
            this.RegPayAmount.Size = new System.Drawing.Size(438, 39);
            this.RegPayAmount.TabIndex = 8;
            this.RegPayAmount.Text = "Regular Payment Amount:";
            // 
            // TotalDiscount
            // 
            this.TotalDiscount.AutoSize = true;
            this.TotalDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalDiscount.Location = new System.Drawing.Point(40, 108);
            this.TotalDiscount.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.TotalDiscount.Name = "TotalDiscount";
            this.TotalDiscount.Size = new System.Drawing.Size(214, 36);
            this.TotalDiscount.TabIndex = 7;
            this.TotalDiscount.Text = "Total Discount:";
            // 
            // MembershipCost
            // 
            this.MembershipCost.AutoSize = true;
            this.MembershipCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MembershipCost.Location = new System.Drawing.Point(40, 46);
            this.MembershipCost.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.MembershipCost.Name = "MembershipCost";
            this.MembershipCost.Size = new System.Drawing.Size(255, 36);
            this.MembershipCost.TabIndex = 6;
            this.MembershipCost.Text = "Membership Cost:";
            // 
            // RegPayBox
            // 
            this.RegPayBox.Cursor = System.Windows.Forms.Cursors.No;
            this.RegPayBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegPayBox.Location = new System.Drawing.Point(619, 179);
            this.RegPayBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.RegPayBox.Name = "RegPayBox";
            this.RegPayBox.ReadOnly = true;
            this.RegPayBox.Size = new System.Drawing.Size(606, 45);
            this.RegPayBox.TabIndex = 5;
            // 
            // NetCostBox
            // 
            this.NetCostBox.Cursor = System.Windows.Forms.Cursors.No;
            this.NetCostBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NetCostBox.Location = new System.Drawing.Point(965, 103);
            this.NetCostBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.NetCostBox.Name = "NetCostBox";
            this.NetCostBox.ReadOnly = true;
            this.NetCostBox.Size = new System.Drawing.Size(260, 45);
            this.NetCostBox.TabIndex = 4;
            // 
            // ExtraBox
            // 
            this.ExtraBox.Cursor = System.Windows.Forms.Cursors.No;
            this.ExtraBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExtraBox.Location = new System.Drawing.Point(965, 41);
            this.ExtraBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.ExtraBox.Name = "ExtraBox";
            this.ExtraBox.ReadOnly = true;
            this.ExtraBox.Size = new System.Drawing.Size(260, 45);
            this.ExtraBox.TabIndex = 3;
            // 
            // MemCostBox
            // 
            this.MemCostBox.Cursor = System.Windows.Forms.Cursors.No;
            this.MemCostBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MemCostBox.Location = new System.Drawing.Point(337, 41);
            this.MemCostBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.MemCostBox.Name = "MemCostBox";
            this.MemCostBox.ReadOnly = true;
            this.MemCostBox.Size = new System.Drawing.Size(260, 45);
            this.MemCostBox.TabIndex = 2;
            // 
            // TextDiscBox
            // 
            this.TextDiscBox.Cursor = System.Windows.Forms.Cursors.No;
            this.TextDiscBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextDiscBox.Location = new System.Drawing.Point(337, 99);
            this.TextDiscBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.TextDiscBox.Name = "TextDiscBox";
            this.TextDiscBox.ReadOnly = true;
            this.TextDiscBox.Size = new System.Drawing.Size(260, 45);
            this.TextDiscBox.TabIndex = 1;
            // 
            // CalculateButton
            // 
            this.CalculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalculateButton.Location = new System.Drawing.Point(86, 1102);
            this.CalculateButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(1253, 72);
            this.CalculateButton.TabIndex = 39;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // Extras
            // 
            this.Extras.Controls.Add(this.fitnessVidCheck);
            this.Extras.Controls.Add(this.dietConsultCheck);
            this.Extras.Controls.Add(this.personalTrainerCheck);
            this.Extras.Controls.Add(this.accessCheck);
            this.Extras.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Extras.Location = new System.Drawing.Point(784, 797);
            this.Extras.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Extras.Name = "Extras";
            this.Extras.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Extras.Size = new System.Drawing.Size(557, 281);
            this.Extras.TabIndex = 38;
            this.Extras.TabStop = false;
            this.Extras.Text = "Extras";
            // 
            // fitnessVidCheck
            // 
            this.fitnessVidCheck.AutoSize = true;
            this.fitnessVidCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fitnessVidCheck.Location = new System.Drawing.Point(98, 221);
            this.fitnessVidCheck.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.fitnessVidCheck.Name = "fitnessVidCheck";
            this.fitnessVidCheck.Size = new System.Drawing.Size(344, 40);
            this.fitnessVidCheck.TabIndex = 9;
            this.fitnessVidCheck.Text = "Fitness Videos Rental";
            this.fitnessVidCheck.UseVisualStyleBackColor = true;
            // 
            // dietConsultCheck
            // 
            this.dietConsultCheck.AutoSize = true;
            this.dietConsultCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dietConsultCheck.Location = new System.Drawing.Point(98, 167);
            this.dietConsultCheck.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.dietConsultCheck.Name = "dietConsultCheck";
            this.dietConsultCheck.Size = new System.Drawing.Size(280, 40);
            this.dietConsultCheck.TabIndex = 8;
            this.dietConsultCheck.Text = "Diet Consultation";
            this.dietConsultCheck.UseVisualStyleBackColor = true;
            // 
            // personalTrainerCheck
            // 
            this.personalTrainerCheck.AutoSize = true;
            this.personalTrainerCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.personalTrainerCheck.Location = new System.Drawing.Point(98, 113);
            this.personalTrainerCheck.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.personalTrainerCheck.Name = "personalTrainerCheck";
            this.personalTrainerCheck.Size = new System.Drawing.Size(273, 40);
            this.personalTrainerCheck.TabIndex = 7;
            this.personalTrainerCheck.Text = "Personal Trainer";
            this.personalTrainerCheck.UseVisualStyleBackColor = true;
            // 
            // accessCheck
            // 
            this.accessCheck.AutoSize = true;
            this.accessCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accessCheck.Location = new System.Drawing.Point(98, 59);
            this.accessCheck.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.accessCheck.Name = "accessCheck";
            this.accessCheck.Size = new System.Drawing.Size(217, 40);
            this.accessCheck.TabIndex = 6;
            this.accessCheck.Text = "24/7 Access";
            this.accessCheck.UseVisualStyleBackColor = true;
            // 
            // PaymentDetails
            // 
            this.PaymentDetails.Controls.Add(this.panel2);
            this.PaymentDetails.Controls.Add(this.frequencylabel);
            this.PaymentDetails.Controls.Add(this.BankAccBox);
            this.PaymentDetails.Controls.Add(this.BankNumber);
            this.PaymentDetails.Controls.Add(this.Method);
            this.PaymentDetails.Controls.Add(this.FrequencyCheck);
            this.PaymentDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentDetails.Location = new System.Drawing.Point(88, 787);
            this.PaymentDetails.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PaymentDetails.Name = "PaymentDetails";
            this.PaymentDetails.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PaymentDetails.Size = new System.Drawing.Size(659, 291);
            this.PaymentDetails.TabIndex = 37;
            this.PaymentDetails.TabStop = false;
            this.PaymentDetails.Text = "Payment Details";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.creditRadio);
            this.panel2.Controls.Add(this.bankRadio);
            this.panel2.Location = new System.Drawing.Point(217, 93);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(359, 53);
            this.panel2.TabIndex = 9;
            // 
            // creditRadio
            // 
            this.creditRadio.AutoSize = true;
            this.creditRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creditRadio.Location = new System.Drawing.Point(185, 8);
            this.creditRadio.Name = "creditRadio";
            this.creditRadio.Size = new System.Drawing.Size(131, 40);
            this.creditRadio.TabIndex = 3;
            this.creditRadio.TabStop = true;
            this.creditRadio.Text = "Credit";
            this.creditRadio.UseVisualStyleBackColor = true;
            // 
            // bankRadio
            // 
            this.bankRadio.AutoSize = true;
            this.bankRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bankRadio.Location = new System.Drawing.Point(17, 8);
            this.bankRadio.Name = "bankRadio";
            this.bankRadio.Size = new System.Drawing.Size(120, 40);
            this.bankRadio.TabIndex = 2;
            this.bankRadio.TabStop = true;
            this.bankRadio.Text = "Bank";
            this.bankRadio.UseVisualStyleBackColor = true;
            // 
            // frequencylabel
            // 
            this.frequencylabel.AutoSize = true;
            this.frequencylabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.frequencylabel.Location = new System.Drawing.Point(40, 229);
            this.frequencylabel.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.frequencylabel.Name = "frequencylabel";
            this.frequencylabel.Size = new System.Drawing.Size(164, 36);
            this.frequencylabel.TabIndex = 9;
            this.frequencylabel.Text = "Frequency:";
            // 
            // BankAccBox
            // 
            this.BankAccBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BankAccBox.Location = new System.Drawing.Point(217, 156);
            this.BankAccBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.BankAccBox.Name = "BankAccBox";
            this.BankAccBox.Size = new System.Drawing.Size(359, 45);
            this.BankAccBox.TabIndex = 3;
            // 
            // BankNumber
            // 
            this.BankNumber.AutoSize = true;
            this.BankNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BankNumber.Location = new System.Drawing.Point(40, 165);
            this.BankNumber.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.BankNumber.Name = "BankNumber";
            this.BankNumber.Size = new System.Drawing.Size(128, 36);
            this.BankNumber.TabIndex = 1;
            this.BankNumber.Text = "Number:";
            // 
            // Method
            // 
            this.Method.AutoSize = true;
            this.Method.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Method.Location = new System.Drawing.Point(45, 105);
            this.Method.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.Method.Name = "Method";
            this.Method.Size = new System.Drawing.Size(123, 36);
            this.Method.TabIndex = 0;
            this.Method.Text = "Method:";
            // 
            // FrequencyCheck
            // 
            this.FrequencyCheck.Controls.Add(this.monthlyRadio);
            this.FrequencyCheck.Controls.Add(this.weeklyRadio);
            this.FrequencyCheck.Location = new System.Drawing.Point(215, 219);
            this.FrequencyCheck.Name = "FrequencyCheck";
            this.FrequencyCheck.Size = new System.Drawing.Size(359, 53);
            this.FrequencyCheck.TabIndex = 8;
            // 
            // monthlyRadio
            // 
            this.monthlyRadio.AutoSize = true;
            this.monthlyRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthlyRadio.Location = new System.Drawing.Point(185, 8);
            this.monthlyRadio.Name = "monthlyRadio";
            this.monthlyRadio.Size = new System.Drawing.Size(158, 40);
            this.monthlyRadio.TabIndex = 3;
            this.monthlyRadio.TabStop = true;
            this.monthlyRadio.Text = "Monthly";
            this.monthlyRadio.UseVisualStyleBackColor = true;
            // 
            // weeklyRadio
            // 
            this.weeklyRadio.AutoSize = true;
            this.weeklyRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weeklyRadio.Location = new System.Drawing.Point(17, 8);
            this.weeklyRadio.Name = "weeklyRadio";
            this.weeklyRadio.Size = new System.Drawing.Size(150, 40);
            this.weeklyRadio.TabIndex = 2;
            this.weeklyRadio.TabStop = true;
            this.weeklyRadio.Text = "Weekly";
            this.weeklyRadio.UseVisualStyleBackColor = true;
            // 
            // MembershipDetails
            // 
            this.MembershipDetails.Controls.Add(this.panel3);
            this.MembershipDetails.Controls.Add(this.MembershipDuration);
            this.MembershipDetails.Controls.Add(this.MembershipType);
            this.MembershipDetails.Controls.Add(this.DurationDetails);
            this.MembershipDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MembershipDetails.Location = new System.Drawing.Point(88, 541);
            this.MembershipDetails.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MembershipDetails.Name = "MembershipDetails";
            this.MembershipDetails.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MembershipDetails.Size = new System.Drawing.Size(1253, 217);
            this.MembershipDetails.TabIndex = 36;
            this.MembershipDetails.TabStop = false;
            this.MembershipDetails.Text = "Membership Details";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.premiumRadio);
            this.panel3.Controls.Add(this.regularRadio);
            this.panel3.Controls.Add(this.basicRadio);
            this.panel3.Location = new System.Drawing.Point(216, 79);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(726, 53);
            this.panel3.TabIndex = 7;
            // 
            // premiumRadio
            // 
            this.premiumRadio.AutoSize = true;
            this.premiumRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.premiumRadio.Location = new System.Drawing.Point(478, 8);
            this.premiumRadio.Name = "premiumRadio";
            this.premiumRadio.Size = new System.Drawing.Size(168, 40);
            this.premiumRadio.TabIndex = 2;
            this.premiumRadio.TabStop = true;
            this.premiumRadio.Text = "Premium";
            this.premiumRadio.UseVisualStyleBackColor = true;
            // 
            // regularRadio
            // 
            this.regularRadio.AutoSize = true;
            this.regularRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regularRadio.Location = new System.Drawing.Point(255, 8);
            this.regularRadio.Name = "regularRadio";
            this.regularRadio.Size = new System.Drawing.Size(157, 40);
            this.regularRadio.TabIndex = 1;
            this.regularRadio.TabStop = true;
            this.regularRadio.Text = "Regular";
            this.regularRadio.UseVisualStyleBackColor = true;
            // 
            // basicRadio
            // 
            this.basicRadio.AutoSize = true;
            this.basicRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.basicRadio.Location = new System.Drawing.Point(23, 8);
            this.basicRadio.Name = "basicRadio";
            this.basicRadio.Size = new System.Drawing.Size(125, 40);
            this.basicRadio.TabIndex = 0;
            this.basicRadio.TabStop = true;
            this.basicRadio.Text = "Basic";
            this.basicRadio.UseVisualStyleBackColor = true;
            // 
            // MembershipDuration
            // 
            this.MembershipDuration.AutoSize = true;
            this.MembershipDuration.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MembershipDuration.Location = new System.Drawing.Point(40, 148);
            this.MembershipDuration.Name = "MembershipDuration";
            this.MembershipDuration.Size = new System.Drawing.Size(136, 36);
            this.MembershipDuration.TabIndex = 5;
            this.MembershipDuration.Text = "Duration:";
            // 
            // MembershipType
            // 
            this.MembershipType.AutoSize = true;
            this.MembershipType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MembershipType.Location = new System.Drawing.Point(44, 89);
            this.MembershipType.Name = "MembershipType";
            this.MembershipType.Size = new System.Drawing.Size(89, 36);
            this.MembershipType.TabIndex = 4;
            this.MembershipType.Text = "Type:";
            // 
            // DurationDetails
            // 
            this.DurationDetails.Controls.Add(this.months24);
            this.DurationDetails.Controls.Add(this.months12);
            this.DurationDetails.Controls.Add(this.months3);
            this.DurationDetails.Location = new System.Drawing.Point(216, 138);
            this.DurationDetails.Name = "DurationDetails";
            this.DurationDetails.Size = new System.Drawing.Size(726, 53);
            this.DurationDetails.TabIndex = 6;
            // 
            // months24
            // 
            this.months24.AutoSize = true;
            this.months24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.months24.Location = new System.Drawing.Point(478, 8);
            this.months24.Name = "months24";
            this.months24.Size = new System.Drawing.Size(193, 40);
            this.months24.TabIndex = 2;
            this.months24.TabStop = true;
            this.months24.Text = "24 Months";
            this.months24.UseVisualStyleBackColor = true;
            // 
            // months12
            // 
            this.months12.AutoSize = true;
            this.months12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.months12.Location = new System.Drawing.Point(255, 8);
            this.months12.Name = "months12";
            this.months12.Size = new System.Drawing.Size(193, 40);
            this.months12.TabIndex = 1;
            this.months12.TabStop = true;
            this.months12.Text = "12 Months";
            this.months12.UseVisualStyleBackColor = true;
            // 
            // months3
            // 
            this.months3.AutoSize = true;
            this.months3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.months3.Location = new System.Drawing.Point(23, 8);
            this.months3.Name = "months3";
            this.months3.Size = new System.Drawing.Size(176, 40);
            this.months3.TabIndex = 0;
            this.months3.TabStop = true;
            this.months3.Text = "3 Months";
            this.months3.UseVisualStyleBackColor = true;
            // 
            // CustomerDetails
            // 
            this.CustomerDetails.Controls.Add(this.MobileBox);
            this.CustomerDetails.Controls.Add(this.AddressBox);
            this.CustomerDetails.Controls.Add(this.LastnameBox);
            this.CustomerDetails.Controls.Add(this.FirstnameBox);
            this.CustomerDetails.Controls.Add(this.MobileNumber);
            this.CustomerDetails.Controls.Add(this.Firstname);
            this.CustomerDetails.Controls.Add(this.Address);
            this.CustomerDetails.Controls.Add(this.Lastname);
            this.CustomerDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerDetails.Location = new System.Drawing.Point(86, 156);
            this.CustomerDetails.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CustomerDetails.Name = "CustomerDetails";
            this.CustomerDetails.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CustomerDetails.Size = new System.Drawing.Size(1253, 358);
            this.CustomerDetails.TabIndex = 44;
            this.CustomerDetails.TabStop = false;
            this.CustomerDetails.Text = "Customer Details";
            // 
            // MobileBox
            // 
            this.MobileBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MobileBox.Location = new System.Drawing.Point(299, 276);
            this.MobileBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MobileBox.MaxLength = 10;
            this.MobileBox.Name = "MobileBox";
            this.MobileBox.Size = new System.Drawing.Size(500, 45);
            this.MobileBox.TabIndex = 4;
            // 
            // AddressBox
            // 
            this.AddressBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressBox.Location = new System.Drawing.Point(299, 214);
            this.AddressBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AddressBox.Name = "AddressBox";
            this.AddressBox.Size = new System.Drawing.Size(897, 45);
            this.AddressBox.TabIndex = 3;
            // 
            // LastnameBox
            // 
            this.LastnameBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastnameBox.Location = new System.Drawing.Point(299, 152);
            this.LastnameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LastnameBox.Name = "LastnameBox";
            this.LastnameBox.Size = new System.Drawing.Size(897, 45);
            this.LastnameBox.TabIndex = 2;
            // 
            // FirstnameBox
            // 
            this.FirstnameBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstnameBox.Location = new System.Drawing.Point(299, 90);
            this.FirstnameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FirstnameBox.Name = "FirstnameBox";
            this.FirstnameBox.Size = new System.Drawing.Size(897, 45);
            this.FirstnameBox.TabIndex = 1;
            // 
            // MobileNumber
            // 
            this.MobileNumber.AutoSize = true;
            this.MobileNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MobileNumber.Location = new System.Drawing.Point(40, 281);
            this.MobileNumber.Name = "MobileNumber";
            this.MobileNumber.Size = new System.Drawing.Size(225, 36);
            this.MobileNumber.TabIndex = 3;
            this.MobileNumber.Text = "Mobile Number:";
            // 
            // Firstname
            // 
            this.Firstname.AutoSize = true;
            this.Firstname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Firstname.Location = new System.Drawing.Point(40, 95);
            this.Firstname.Name = "Firstname";
            this.Firstname.Size = new System.Drawing.Size(153, 36);
            this.Firstname.TabIndex = 0;
            this.Firstname.Text = "Firstname:";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address.Location = new System.Drawing.Point(40, 219);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(134, 36);
            this.Address.TabIndex = 2;
            this.Address.Text = "Address:";
            // 
            // Lastname
            // 
            this.Lastname.AutoSize = true;
            this.Lastname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lastname.Location = new System.Drawing.Point(40, 157);
            this.Lastname.Name = "Lastname";
            this.Lastname.Size = new System.Drawing.Size(151, 36);
            this.Lastname.TabIndex = 1;
            this.Lastname.Text = "Lastname:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(425, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(517, 55);
            this.label7.TabIndex = 43;
            this.label7.Text = "City Gym Membership";
            // 
            // GymMembership
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1426, 1576);
            this.Controls.Add(this.CustomerDetails);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.DataSuccess);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.Extras);
            this.Controls.Add(this.PaymentDetails);
            this.Controls.Add(this.MembershipDetails);
            this.Name = "GymMembership";
            this.Text = "Gym Membership";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Extras.ResumeLayout(false);
            this.Extras.PerformLayout();
            this.PaymentDetails.ResumeLayout(false);
            this.PaymentDetails.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.FrequencyCheck.ResumeLayout(false);
            this.FrequencyCheck.PerformLayout();
            this.MembershipDetails.ResumeLayout(false);
            this.MembershipDetails.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.DurationDetails.ResumeLayout(false);
            this.DurationDetails.PerformLayout();
            this.CustomerDetails.ResumeLayout(false);
            this.CustomerDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Button CloseButton;
        private System.Windows.Forms.TextBox DataSuccess;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label NetMembershipCost;
        private System.Windows.Forms.Label ExtraCharges;
        private System.Windows.Forms.Label RegPayAmount;
        private System.Windows.Forms.Label TotalDiscount;
        private System.Windows.Forms.Label MembershipCost;
        private System.Windows.Forms.TextBox RegPayBox;
        private System.Windows.Forms.TextBox NetCostBox;
        private System.Windows.Forms.TextBox ExtraBox;
        private System.Windows.Forms.TextBox MemCostBox;
        private System.Windows.Forms.TextBox TextDiscBox;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.GroupBox Extras;
        private System.Windows.Forms.CheckBox fitnessVidCheck;
        private System.Windows.Forms.CheckBox dietConsultCheck;
        private System.Windows.Forms.CheckBox personalTrainerCheck;
        private System.Windows.Forms.CheckBox accessCheck;
        private System.Windows.Forms.GroupBox PaymentDetails;
        private System.Windows.Forms.TextBox BankAccBox;
        private System.Windows.Forms.Label BankNumber;
        private System.Windows.Forms.Label Method;
        private System.Windows.Forms.Panel FrequencyCheck;
        private System.Windows.Forms.RadioButton monthlyRadio;
        private System.Windows.Forms.RadioButton weeklyRadio;
        private System.Windows.Forms.GroupBox MembershipDetails;
        private System.Windows.Forms.Label MembershipDuration;
        private System.Windows.Forms.Label MembershipType;
        private System.Windows.Forms.Panel DurationDetails;
        private System.Windows.Forms.RadioButton months24;
        private System.Windows.Forms.RadioButton months12;
        private System.Windows.Forms.RadioButton months3;
        private System.Windows.Forms.GroupBox CustomerDetails;
        private System.Windows.Forms.TextBox MobileBox;
        private System.Windows.Forms.TextBox AddressBox;
        private System.Windows.Forms.TextBox LastnameBox;
        private System.Windows.Forms.TextBox FirstnameBox;
        private System.Windows.Forms.Label MobileNumber;
        private System.Windows.Forms.Label Firstname;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label Lastname;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton creditRadio;
        private System.Windows.Forms.RadioButton bankRadio;
        private System.Windows.Forms.Label frequencylabel;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton premiumRadio;
        private System.Windows.Forms.RadioButton regularRadio;
        private System.Windows.Forms.RadioButton basicRadio;
    }
}

