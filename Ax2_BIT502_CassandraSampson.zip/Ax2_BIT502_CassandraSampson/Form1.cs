﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ax2_BIT502_CassandraSampson
{
    public partial class GymMembership : Form
    {
        public GymMembership()
        {
            this.Controls.Clear();
            InitializeComponent();
        }

        double weeklyPayment;
        double discount;
        double bankDiscount;
        double extraCost;
        double monthlyPayment;
        string frequency;
        string typeOfPayment;
        const string path = "C:/Temp/members.txt";

        private double calculateType()
        {
            weeklyPayment = 0;
            if (basicRadio.Checked)
            {
                weeklyPayment = 10;
            }
            else if (regularRadio.Checked)
            {
                weeklyPayment = 15;
            }
            else if (premiumRadio.Checked)
            {
                weeklyPayment = 20;
            }
            return weeklyPayment;
        }

        private double calculateDiscount()
        {
            discount = 0;
            if (months12.Checked)
            {
                discount = 2;
            }
            else if (months24.Checked)
            {
                discount = 5;
            }
            else //if 3 months is checked
            {
                discount = 0;
            }
            return discount;
        }

        private double calculateBankDiscount()
        {
            //to calculate 
            bankDiscount = 0;

            if (bankRadio.Checked && basicRadio.Checked)
            {
                bankDiscount = 0.1;
            }
            else if (bankRadio.Checked && regularRadio.Checked)
            {
                bankDiscount = 0.15;
            }
            else if (bankRadio.Checked && premiumRadio.Checked)
            {
                bankDiscount = 0.2;
            }
            return bankDiscount;
        }

        


        private double calculateExtra()
        {
            var extras = new[]
            {
                new { CheckBox = accessCheck, extraCost = 1,},
                new { CheckBox = personalTrainerCheck, extraCost = 20,},
                new { CheckBox = dietConsultCheck, extraCost = 20,},
                new { CheckBox = fitnessVidCheck, extraCost = 2,},
            };

            var extraCost = 0;
            foreach (var check in extras)
            {
                if (check.CheckBox.Checked)
                {
                    extraCost += check.extraCost;
                }
            }
            return extraCost;

            //this section adds extra charges to the base membership cost
            //extraCost = 0;
            //if (accessCheck.Checked)
            //{
            //    extraCost += 1;
            //}
            //if (personalTrainerCheck.Checked)
            //{
            //    extraCost += 20;
            //}
            //if (dietConsultCheck.Checked)
            //{
            //    extraCost += 20;
            //}
            //if (fitnessVidCheck.Checked)
            //{
            //    extraCost += 2;
            //}
            //return extraCost;
        }
        
        private string paymentFrequency()
        {
            // to determine the frequency of payment by the client
            if (weeklyRadio.Checked)
            {
                frequency = "Weekly";
            }
            else if (monthlyRadio.Checked)
            {
                frequency = "Monthly";
            }
            return frequency;
        }

        private string paymentType()
        {
            if (bankRadio.Checked)
            {
                typeOfPayment = "Bank account";
            }
            else
            {
                typeOfPayment = "Credit card";
            }
            return typeOfPayment;       
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {

            //Method where the calculations are made when the CALCULATE button is pressed          

            DataSuccess.Clear(); //this will clear the message about the file being successfully written once the calculator is used again

            double overallDiscount = calculateDiscount() + calculateBankDiscount(); // to get the discounts from the duration and bank payment form options
            double payment = calculateType() + calculateExtra(); //to get base membership + extras if there are any
            double netMembershipCost = payment - overallDiscount; // to get total cost of membership including discounts

            if (monthlyRadio.Checked) //this statement is executed if the monthly payment frequency has been clicked and will show the regular payment textbox with the monthly total to pay
            {
                monthlyPayment = netMembershipCost * 4;                
                MemCostBox.Text = calculateType().ToString(); //membership cost box (base cost)
                NetCostBox.Text = netMembershipCost.ToString(); //net membership cost box
                ExtraBox.Text = calculateExtra().ToString(); //extra costs box
                TextDiscBox.Text = overallDiscount.ToString(); //total discount box
                RegPayBox.Text = monthlyPayment.ToString(); //regular payment box which includes the monthly cost including discounts if applicable
            }
            else // this will display the regular payment text box with the total per week
            {
                MemCostBox.Text = calculateType().ToString(); //membership cost box (base cost)
                NetCostBox.Text = netMembershipCost.ToString(); //net membership cost box
                ExtraBox.Text = calculateExtra().ToString(); //extra costs box
                TextDiscBox.Text = overallDiscount.ToString(); //total discount box
                RegPayBox.Text = netMembershipCost.ToString(); // showing the net membership costs again 
            }                  

        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            using (TextWriter memberDetails = new StreamWriter(path, true))
            {                
                memberDetails.WriteLine("Firsname: " + FirstnameBox.Text);
                memberDetails.WriteLine("Lastname: " + LastnameBox.Text);
                memberDetails.WriteLine("Address: " + AddressBox.Text);
                memberDetails.WriteLine("Mobile number: " + MobileBox.Text);
                memberDetails.WriteLine("Regular payment amount: " + "$" + RegPayBox.Text);
                memberDetails.WriteLine("Number of bank account or credit card: " + paymentType());
                memberDetails.WriteLine("Frequency of payment: " + paymentFrequency());
                memberDetails.WriteLine("");
                memberDetails.Close();

                DataSuccess.Text = "The data has been written successfully";
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
